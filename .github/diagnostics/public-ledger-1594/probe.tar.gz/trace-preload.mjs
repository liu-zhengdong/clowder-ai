import { channel } from 'node:diagnostics_channel';
import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = resolve(process.env.R04_SOURCE_ROOT);
const { RunLedger } = await import(pathToFileURL(join(root, 'packages/api/dist/infrastructure/scheduler/RunLedger.js')));
const { SqliteEvidenceStore } = await import(pathToFileURL(join(root, 'packages/api/dist/domains/memory/SqliteEvidenceStore.js')));
const samples = [];
const checkpoints = [];
let phase = 'before-projection';
let stagedRows = 0;
let observedDb;
let begin;
let end;
let engine;
let probeSetupMs;
const start = performance.now();
channel('cat-cafe.entity-mention-projection').subscribe((event) => {
  phase = event.phase;
  if (event.phase === 'staging') stagedRows = event.rows;
});
channel('cat-cafe.entity-mention-checkpoint').subscribe((event) => {
  checkpoints.push({ atMs: performance.now() - start, ...event });
});
function scheduler() {
  if (process.platform !== 'linux') return null;
  try {
    const [runNs, waitNs, slices] = readFileSync(`/proc/self/task/${process.pid}/schedstat`, 'utf8').trim().split(/\s+/).map(Number);
    return { runNs, waitNs, slices };
  } catch (error) {
    return { unavailable: error.code };
  }
}
const initialize = SqliteEvidenceStore.prototype.initialize;
SqliteEvidenceStore.prototype.initialize = async function (...args) {
  const value = await initialize.apply(this, args);
  if (!observedDb) {
    const setup = performance.now();
    observedDb = this.getDb();
    observedDb.loadExtension(process.env.R04_VFS_EXTENSION);
    engine = observedDb.prepare('SELECT sqlite_version() AS version, sqlite_source_id() AS source').get();
    begin = observedDb.prepare('SELECT io_probe_begin()');
    end = observedDb.prepare('SELECT io_probe_end() AS value');
    probeSetupMs = performance.now() - setup;
  }
  return value;
};
const record = RunLedger.prototype.record;
RunLedger.prototype.record = function (...args) {
  if (this.db !== observedDb) throw new Error('Trace supports exactly one fixture connection');
  const scheduledBefore = scheduler();
  const usageBefore = process.resourceUsage();
  const cpuBefore = process.cpuUsage();
  begin.get();
  const started = performance.now();
  let durationMs;
  try {
    const value = record.apply(this, args);
    durationMs = performance.now() - started;
    return value;
  } finally {
    durationMs ??= performance.now() - started;
    const io = JSON.parse(end.get().value);
    const cpuUs = process.cpuUsage(cpuBefore);
    const usageAfter = process.resourceUsage();
    const scheduledAfter = scheduler();
    const usage = Object.fromEntries(['voluntaryContextSwitches', 'involuntaryContextSwitches', 'majorPageFault', 'minorPageFault', 'fsRead', 'fsWrite'].map((key) => [key, usageAfter[key] - usageBefore[key]]));
    const scheduled = scheduledBefore?.runNs !== undefined && scheduledAfter?.runNs !== undefined
      ? Object.fromEntries(['runNs', 'waitNs', 'slices'].map((key) => [key, scheduledAfter[key] - scheduledBefore[key]]))
      : { before: scheduledBefore, after: scheduledAfter };
    samples.push({ atMs: started - start, durationMs, phase, stagedRows, io, cpuUs, usage, scheduled });
  }
};
process.once('exit', () => {
  if (!samples.length) return;
  const output = join(process.env.R04_TRACE_DIR, `ledger-trace-${process.pid}.json`);
  writeFileSync(output, JSON.stringify({ platform: process.platform, arch: process.arch, node: process.version, engine, probeSetupMs, samples, checkpoints }, null, 2) + '\n');
});
