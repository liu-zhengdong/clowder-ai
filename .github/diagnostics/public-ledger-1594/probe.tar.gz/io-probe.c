#include "sqlite3ext.h"
SQLITE_EXTENSION_INIT1
#include <time.h>
#include <stdio.h>
#include <string.h>

typedef struct { sqlite3_file *file; const sqlite3_io_methods *original; sqlite3_io_methods wrapped; long reads,writes,bytes,syncs,locks,shmLocks; double readMs,writeMs,syncMs,lockMs,shmLockMs; long headerWrites,lockBusy,shmBusy; } Metric;
static Metric files[2];
static sqlite3_vfs *vfs;
static int (*originalSleep)(sqlite3_vfs*,int);
static long sleepCalls=0,sleepMicros=0;
static double sleepMs=0;
static int active=0, delaySyncMs=0;
static double nowMs(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000.0+t.tv_nsec/1000000.0;}
static int slp(sqlite3_vfs*v,int us){double t=nowMs();int r=originalSleep(v,us);if(active){sleepCalls++;sleepMicros+=us;sleepMs+=nowMs()-t;}return r;}
static Metric *metric(sqlite3_file *f){return f==files[0].file ? &files[0] : &files[1];}
static int rd(sqlite3_file*f,void*b,int n,sqlite3_int64 o){Metric*m=metric(f);double t=nowMs();int r=m->original->xRead(f,b,n,o);if(active){m->reads++;m->readMs+=nowMs()-t;}return r;}
static int wr(sqlite3_file*f,const void*b,int n,sqlite3_int64 o){Metric*m=metric(f);double t=nowMs();int r=m->original->xWrite(f,b,n,o);if(active){m->writes++;m->bytes+=n;if(m==&files[1]&&o==0&&n==32)m->headerWrites++;m->writeMs+=nowMs()-t;}return r;}
static int sy(sqlite3_file*f,int flags){Metric*m=metric(f);double t=nowMs();if(active&&delaySyncMs){struct timespec z={delaySyncMs/1000,(delaySyncMs%1000)*1000000L};nanosleep(&z,0);}int r=m->original->xSync(f,flags);if(active){m->syncs++;m->syncMs+=nowMs()-t;}return r;}
static int lk(sqlite3_file*f,int flags){Metric*m=metric(f);double t=nowMs();int r=m->original->xLock(f,flags);if(active){m->locks++;if(r!=SQLITE_OK)m->lockBusy++;m->lockMs+=nowMs()-t;}return r;}
static int sl(sqlite3_file*f,int o,int n,int flags){Metric*m=metric(f);double t=nowMs();int r=m->original->xShmLock(f,o,n,flags);if(active){m->shmLocks++;if(r!=SQLITE_OK)m->shmBusy++;m->shmLockMs+=nowMs()-t;}return r;}
static int cl(sqlite3_file*f){Metric*m=metric(f);f->pMethods=m->original;return m->original->xClose(f);}
static void begin(sqlite3_context*c,int n,sqlite3_value**v){(void)n;(void)v;sleepCalls=sleepMicros=0;sleepMs=0;for(int i=0;i<2;i++){files[i].headerWrites=files[i].lockBusy=files[i].shmBusy=files[i].reads=files[i].writes=files[i].bytes=files[i].syncs=files[i].locks=files[i].shmLocks=0;files[i].readMs=files[i].writeMs=files[i].syncMs=files[i].lockMs=files[i].shmLockMs=0;}active=1;sqlite3_result_null(c);}
static void end(sqlite3_context*c,int n,sqlite3_value**v){(void)n;(void)v;active=0;char b[2048];Metric*a=&files[0],*w=&files[1];snprintf(b,sizeof b,"{\"sleepCalls\":%ld,\"sleepRequestedUs\":%ld,\"sleepMs\":%.6f,\"walHeaderWrites\":%ld,\"lockFailures\":%ld,\"shmFailures\":%ld,\"main\":{\"reads\":%ld,\"writes\":%ld,\"bytes\":%ld,\"syncs\":%ld,\"locks\":%ld,\"shmLocks\":%ld,\"readMs\":%.6f,\"writeMs\":%.6f,\"syncMs\":%.6f,\"lockMs\":%.6f,\"shmLockMs\":%.6f},\"wal\":{\"reads\":%ld,\"writes\":%ld,\"bytes\":%ld,\"syncs\":%ld,\"readMs\":%.6f,\"writeMs\":%.6f,\"syncMs\":%.6f}}",sleepCalls,sleepMicros,sleepMs,w->headerWrites,a->lockBusy,a->shmBusy,a->reads,a->writes,a->bytes,a->syncs,a->locks,a->shmLocks,a->readMs,a->writeMs,a->syncMs,a->lockMs,a->shmLockMs,w->reads,w->writes,w->bytes,w->syncs,w->readMs,w->writeMs,w->syncMs);sqlite3_result_text(c,b,-1,SQLITE_TRANSIENT);}
static void delay(sqlite3_context*c,int n,sqlite3_value**v){(void)n;delaySyncMs=sqlite3_value_int(v[0]);sqlite3_result_null(c);}
int sqlite3_extension_init(sqlite3*db,char**error,const sqlite3_api_routines*api){SQLITE_EXTENSION_INIT2(api);(void)error;int controls[]={SQLITE_FCNTL_FILE_POINTER,SQLITE_FCNTL_JOURNAL_POINTER};for(int i=0;i<2;i++){Metric*m=&files[i];int r=sqlite3_file_control(db,"main",controls[i],&m->file);if(r!=SQLITE_OK||!m->file)return SQLITE_ERROR;m->original=m->file->pMethods;m->wrapped=*m->original;m->wrapped.xClose=cl;m->wrapped.xRead=rd;m->wrapped.xWrite=wr;m->wrapped.xSync=sy;m->wrapped.xLock=lk;if(m->wrapped.xShmLock)m->wrapped.xShmLock=sl;m->file->pMethods=&m->wrapped;}sqlite3_file_control(db,"main",SQLITE_FCNTL_VFS_POINTER,&vfs);originalSleep=vfs->xSleep;vfs->xSleep=slp;sqlite3_create_function(db,"io_probe_begin",0,SQLITE_UTF8,0,begin,0,0);sqlite3_create_function(db,"io_probe_end",0,SQLITE_UTF8,0,end,0,0);sqlite3_create_function(db,"io_probe_delay_sync",1,SQLITE_UTF8,0,delay,0,0);return SQLITE_OK;}
