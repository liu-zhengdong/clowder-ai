import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
const here = dirname(fileURLToPath(import.meta.url));
mkdirSync(output, { recursive: true });
const require = createRequire(join(root, 'packages/api/package.json'));
const binding = dirname(require.resolve('better-sqlite3/package.json'));
const extension = join(output, process.platform === 'darwin' ? 'r04-io.dylib' : 'r04-io.so');
execFileSync('cc', ['-O2', '-shared', '-fPIC', '-I', join(binding, 'deps/sqlite3'), join(here, 'io-probe.c'), '-o', extension], { stdio: 'inherit' });
const testPath = join(root, 'packages/api/test/memory/entity-projection-liveness.test.js');
const sha256 = (path) => createHash('sha256').update(readFileSync(path)).digest('hex');
const originalHash = sha256(testPath);
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
const result = spawnSync(process.execPath, ['--import', join(here, 'trace-preload.mjs'), '--test', testPath], {
  cwd: root,
  stdio: 'inherit',
  timeout: 90_000,
  env: { ...process.env, R04_SOURCE_ROOT: root, R04_TRACE_DIR: output, R04_VFS_EXTENSION: extension },
});
const receipt = { head, platform: process.platform, arch: process.arch, node: process.version, originalTestSha256: originalHash, finalTestSha256: sha256(testPath), exit: result.status, signal: result.signal, error: result.error?.message };
writeFileSync(join(output, 'trace-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
if (receipt.originalTestSha256 !== receipt.finalTestSha256) throw new Error('Original regression changed');
process.exitCode = result.status ?? 1;
